<?php

interface IModuleBase
{
    function Run(array $data = []) : void;
}
