<?php

enum AllowedMimes : string
{
    case JPG = "image/jpeg";
    case PNG = "image/png";
}
